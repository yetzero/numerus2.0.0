---
title: Badge hd
categories:
  - Badges
tags:
  - display
  - resolution
  - "high definition"
---
