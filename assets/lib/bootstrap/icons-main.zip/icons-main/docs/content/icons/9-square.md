---
title: 9 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
